Leaflet.GeometryUtil
====================

[![Build Status](https://travis-ci.org/makinacorpus/Leaflet.GeometryUtil.png?branch=master)](https://travis-ci.org/makinacorpus/Leaflet.GeometryUtil)

* Tested with stable Leaflet 0.5.1

## Running tests in command-line

* Install [nodejs](http://nodejs.org) and [phantomjs](http://phantomjs.org)

```
    sudo apt-get install nodejs phantomjs
```

* Ready !

```
    make test
```
